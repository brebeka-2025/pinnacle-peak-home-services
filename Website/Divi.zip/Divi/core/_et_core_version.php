<?php
/**
 * Define the current ET Core version
 *
 * (Note: this value updates automatically as part of our Grunt release task)
 *
 * @package \ET\Core
 */

// Note, this will be updated automatically during grunt release task
$ET_CORE_VERSION = '4.27.5';
